#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/8/6 14:51
# @Author  : Liupj
# @Desc    : 模块
# @File    : moduler.py
# @Software: PyCharm
name = 'Songsa'
def sayHi():
    print("Hi ",name)

def sayHello():
    print("Hello")

sayHi()
sayHello()