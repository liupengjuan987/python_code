#!/usr/bin/env python
# -*- coding: utf-8 -*-
# @Time    : 2020/8/6 21:49
# @Author  : Liupj
# @Desc    : 
# @File    : lyric.py
# @Software: PyCharm

天青色等烟雨